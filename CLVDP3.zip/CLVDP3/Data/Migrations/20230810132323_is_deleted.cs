﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CLVDP3.Data.Migrations
{
    /// <inheritdoc />
    public partial class is_deleted : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
    name: "is_deleted",
    table: "Driver", // Replace with your table name
    type: "bit",
    nullable: false,
    defaultValue: false);

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
    name: "is_deleted",
    table: "Driver"); // Replace with your table name

        }
    }
}
