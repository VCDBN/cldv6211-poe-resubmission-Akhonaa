﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CLVDP3.Data.Migrations
{
    /// <inheritdoc />
    public partial class Been_Deleted : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "deleted",
                table: "Rental",
                newName: "Been_Deleted");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Been_Deleted",
                table: "Rental",
                newName: "deleted");
        }
    }
}
