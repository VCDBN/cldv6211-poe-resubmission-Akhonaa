﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CLVDP3.Data.Migrations
{
    /// <inheritdoc />
    public partial class Deleted_Info : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "Deleted_Info",
                table: "Return",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Deleted_Info",
                table: "Return");
        }
    }
}
