﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CLVDP3.Models;

[Table("Rental")]
public partial class Rental
{
    [Key]
    [Column("Rental_ID")]
    public int RentalId { get; set; }

    [Column("Rental_Fee")]
    public int RentalFee { get; set; }

    [Column("Start_Date", TypeName = "datetime")]
    public DateTime StartDate { get; set; }

    [Column("End_Date", TypeName = "datetime")]
    public DateTime EndDate { get; set; }

    [Column("Car_ID")]
    public int CarId { get; set; }

    [Column("Driver_ID")]
    public int DriverId { get; set; }

    [Column("Inspector_ID")]
    public int InspectorId { get; set; }

    [Column("Been_Deleted")]
    public bool BeenDeleted { get; set; } = false;  // Default value

    [ForeignKey("CarId")]
    [InverseProperty("Rentals")]
    public virtual Car Car { get; set; } = null!;

    [ForeignKey("DriverId")]
    [InverseProperty("Rentals")]
    public virtual Driver Driver { get; set; } = null!;

    [ForeignKey("InspectorId")]
    [InverseProperty("Rentals")]
    public virtual Inspector Inspector { get; set; } = null!;

    [InverseProperty("Rental")]
    public virtual ICollection<Return> Returns { get; set; } = new List<Return>();
}
