﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CLVDP3.Models;

[Table("Inspector")]
public partial class Inspector
{
    [Key]
    [Column("Inspector_ID")]
    public int InspectorId { get; set; }

    [Column("Inspector_name")]
    [StringLength(60)]
    [Unicode(false)]
    public string InspectorName { get; set; } = null!;

    [Column("Inspector_email")]
    [StringLength(50)]
    [Unicode(false)]
    public string InspectorEmail { get; set; } = null!;

    [Column("mobile")]
    public int Mobile { get; set; }

    [Column("IsDeleted")]  // New column for soft delete
    public bool IsDeleted { get; set; } = false;  // Set to false by default

    [InverseProperty("Inspector")]
    public virtual ICollection<Rental> Rentals { get; set; } = new List<Rental>();

    [InverseProperty("Inspector")]
    public virtual ICollection<Return> Returns { get; set; } = new List<Return>();
}
