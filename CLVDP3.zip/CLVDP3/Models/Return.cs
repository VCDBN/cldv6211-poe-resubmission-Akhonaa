﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CLVDP3.Models;

public partial class Return
{
    [Key]
    [Column("Returns_ID")]
    public int ReturnsId { get; set; }

    [Column("Return_Date", TypeName = "datetime")]
    public DateTime ReturnDate { get; set; }

    [Column("Elapsed_Date")]
    public int ElapsedDate { get; set; }

    [Column("Inspector_ID")]
    public int InspectorId { get; set; }

    [Column("Rental_ID")]
    public int RentalId { get; set; }
    
    [Column("Deleted_Info")]  // New column for soft delete
    public bool DeletedInfo { get; set; } = false;  // Set to false by default
    public int Fine { get; set; }

    [ForeignKey("InspectorId")]
    [InverseProperty("Returns")]
    public virtual Inspector Inspector { get; set; } = null!;

    [ForeignKey("RentalId")]
    [InverseProperty("Returns")]
    public virtual Rental Rental { get; set; } = null!;
}
