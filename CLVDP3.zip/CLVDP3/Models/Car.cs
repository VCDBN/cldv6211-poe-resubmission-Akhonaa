﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CLVDP3.Models;

[Table("Car")]
public partial class Car
{
    [Key]
    [Column("Car_ID")]
    public int CarId { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string Model { get; set; } = null!;

    [Column("Kilo_traveled")]
    public int KiloTraveled { get; set; }

    [Column("Service_kilo")]
    public int ServiceKilo { get; set; }

    [StringLength(5)]
    [Unicode(false)]
    public string Availability { get; set; } = null!;

    [Column("carMake_ID")]
    public int CarMakeId { get; set; }

    [Column("model_ID")]
    public int ModelId { get; set; }

    [ForeignKey("CarMakeId")]
    [InverseProperty("Cars")]
    public virtual CarMake CarMake { get; set; } = null!;

    [ForeignKey("ModelId")]
    [InverseProperty("Cars")]
    public virtual CarBodyType ModelNavigation { get; set; } = null!;

    [InverseProperty("Car")]
    public virtual ICollection<Rental> Rentals { get; set; } = new List<Rental>();
}
