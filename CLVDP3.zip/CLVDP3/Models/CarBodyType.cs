﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CLVDP3.Models;

[Table("carBodyType")]
public partial class CarBodyType
{
    [Key]
    [Column("model_ID")]
    public int ModelId { get; set; }

    [Column("CarBodyType")]
    [StringLength(15)]
    [Unicode(false)]
    public string CarBodyType1 { get; set; } = null!;
    public bool IsDeleted { get; set; } = false; // Soft delete flag

    [InverseProperty("ModelNavigation")]
    public virtual ICollection<Car> Cars { get; set; } = new List<Car>();
}
