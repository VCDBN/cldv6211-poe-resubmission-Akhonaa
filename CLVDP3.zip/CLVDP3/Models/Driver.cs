﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CLVDP3.Models
{
    [Table("driver")]
    public partial class Driver
    {
        [Key]
        [Column("Driver_ID")]
        public int DriverId { get; set; }

        [Column("name")]
        [StringLength(50)]
        [Unicode(false)]
        public string Name { get; set; } = null!;

        [Column("address")]
        [StringLength(100)]
        [Unicode(false)]
        public string Address { get; set; } = null!;

        [Column("email")]
        [StringLength(50)]
        [Unicode(false)]
        public string Email { get; set; } = null!;

        [Column("mobile")]
        public int Mobile { get; set; }

        // New property for soft delete
        [Column("is_deleted")]
        public bool IsDeleted { get; set; }

        [InverseProperty("Driver")]
        public virtual ICollection<Rental> Rentals { get; set; } = new List<Rental>();
    }
}
