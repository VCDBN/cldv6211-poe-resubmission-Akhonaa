﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CLVDP3.Models;

public partial class ApplicationDbContext2 : DbContext
{
    public ApplicationDbContext2()
    {
    }

    public ApplicationDbContext2(DbContextOptions<ApplicationDbContext2> options)
        : base(options)
    {
    }

    public virtual DbSet<Car> Cars { get; set; }

    public virtual DbSet<CarBodyType> CarBodyTypes { get; set; }

    public virtual DbSet<CarMake> CarMakes { get; set; }

    public virtual DbSet<Driver> Drivers { get; set; }

    public virtual DbSet<Inspector> Inspectors { get; set; }

    public virtual DbSet<Rental> Rentals { get; set; }

    public virtual DbSet<Return> Returns { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=tcp:st10083153.database.windows.net,1433;Initial Catalog=RideYouRentP3;Persist Security Info=False;User ID=ST10083153;Password=Znomsa28;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Car>(entity =>
        {
            entity.HasKey(e => e.CarId).HasName("PK__Car__523653D9D0EA88D1");

            entity.HasOne(d => d.CarMake).WithMany(p => p.Cars)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Car__carMake_ID__68487DD7");

            entity.HasOne(d => d.ModelNavigation).WithMany(p => p.Cars)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Car__model_ID__693CA210");
        });

        modelBuilder.Entity<CarBodyType>(entity =>
        {
            entity.HasKey(e => e.ModelId).HasName("PK__carBodyT__DC38D6ECAB8EA926");
        });

        modelBuilder.Entity<CarMake>(entity =>
        {
            entity.HasKey(e => e.CarMakeId).HasName("PK__carMake__0431F46140CE9EB2");
        });

        modelBuilder.Entity<Driver>(entity =>
        {
            entity.HasKey(e => e.DriverId).HasName("PK__driver__F4664ED9B5DC77B6");
        });

        modelBuilder.Entity<Inspector>(entity =>
        {
            entity.HasKey(e => e.InspectorId).HasName("PK__Inspecto__F49EF385DB68BBF3");
        });

        modelBuilder.Entity<Rental>(entity =>
        {
            entity.HasKey(e => e.RentalId).HasName("PK__Rental__9D23A4462599F9C3");

            entity.HasOne(d => d.Car).WithMany(p => p.Rentals)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Rental__Car_ID__6A30C649");

            entity.HasOne(d => d.Driver).WithMany(p => p.Rentals)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Rental__Driver_I__6B24EA82");

            entity.HasOne(d => d.Inspector).WithMany(p => p.Rentals)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Rental__Inspecto__6C190EBB");
        });

        modelBuilder.Entity<Return>(entity =>
        {
            entity.HasKey(e => e.ReturnsId).HasName("PK__Returns__02519830B5207D1A");

            entity.HasOne(d => d.Inspector).WithMany(p => p.Returns)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Returns__Inspect__6D0D32F4");

            entity.HasOne(d => d.Rental).WithMany(p => p.Returns)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Returns__Rental___6E01572D");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
