﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CLVDP3.Models;

[Table("carMake")]
public partial class CarMake
{
    [Key]
    [Column("carMake_ID")]
    public int CarMakeId { get; set; }

    [Column("carMake")]
    [StringLength(20)]
    [Unicode(false)]
    public string CarMake1 { get; set; } = null!;

    [InverseProperty("CarMake")]
    public virtual ICollection<Car> Cars { get; set; } = new List<Car>();
}
