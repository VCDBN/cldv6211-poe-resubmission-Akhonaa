﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CLVDP3.Models;
using Microsoft.AspNetCore.Authorization;

namespace CLVDP3.Controllers
{
    [Authorize]
    public class ReturnController : Controller
    {
        private readonly ApplicationDbContext2 _context;

        public ReturnController(ApplicationDbContext2 context)
        {
            _context = context;
        }

        // GET: Return
        public async Task<IActionResult> Index()
        {
            var applicationDbContext2 = _context.Returns.Include(r => r.Inspector).Include(r => r.Rental);
            return View(await applicationDbContext2.ToListAsync());
        }

        // GET: Return/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Returns == null)
            {
                return NotFound();
            }

            var @return = await _context.Returns
                .Include(r => r.Inspector)
                .Include(r => r.Rental)
                .FirstOrDefaultAsync(m => m.ReturnsId == id);
            if (@return == null)
            {
                return NotFound();
            }

            return View(@return);
        }

        // GET: Return/Create
        public IActionResult Create()
        {
            ViewData["InspectorId"] = new SelectList(_context.Inspectors, "InspectorId", "InspectorId");
            ViewData["RentalId"] = new SelectList(_context.Rentals, "RentalId", "RentalId");
            return View();
        }

        // POST: Return/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ReturnsId,ReturnDate,ElapsedDate,InspectorId,RentalId,Fine")] Return @return)
        {
            if (ModelState.IsValid)
            {
                _context.Add(@return);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["InspectorId"] = new SelectList(_context.Inspectors, "InspectorId", "InspectorId", @return.InspectorId);
            ViewData["RentalId"] = new SelectList(_context.Rentals, "RentalId", "RentalId", @return.RentalId);
            return View(@return);
        }

        // GET: Return/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null )//|| _context.Returns == null)
            {
                return NotFound();
            }

            var @return = await _context.Returns.FindAsync(id);
            if (@return == null)
            {
                return NotFound();
            }
            ViewData["InspectorId"] = new SelectList(_context.Inspectors, "InspectorId", "InspectorId", @return.InspectorId);
            ViewData["RentalId"] = new SelectList(_context.Rentals, "RentalId", "RentalId", @return.RentalId);
            return View(@return);
        }

        // POST: Return/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ReturnsId,ReturnDate,ElapsedDate,InspectorId,RentalId,Fine")] Return @return)
        {
            if (id != @return.ReturnsId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(@return);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ReturnExists(@return.ReturnsId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["InspectorId"] = new SelectList(_context.Inspectors, "InspectorId", "InspectorId", @return.InspectorId);
            ViewData["RentalId"] = new SelectList(_context.Rentals, "RentalId", "RentalId", @return.RentalId);
            return View(@return);
        }

        // GET: Return/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Returns == null)
            {
                return NotFound();
            }

            var @return = await _context.Returns
                .Include(r => r.Inspector)
                .Include(r => r.Rental)
                .FirstOrDefaultAsync(m => m.ReturnsId == id);
            if (@return == null)
            {
                return NotFound();
            }

            return View(@return);
        }

        // POST: Return/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Returns == null)
            {
                return Problem("Entity set 'ApplicationDbContext2.Returns' is null.");
            }
            var @return = await _context.Returns.FindAsync(id);
            if (@return != null)
            {
                _context.Returns.Remove(@return);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ReturnExists(int id)
        {
            return (_context.Returns?.Any(e => e.ReturnsId == id)).GetValueOrDefault();
        }
    }
}
